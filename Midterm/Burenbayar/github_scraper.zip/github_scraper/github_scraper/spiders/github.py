import scrapy


class GithubSpider(scrapy.Spider):
    name = "github"
    allowed_domains = ["github.com"]
    start_urls = ["https://github.com/burenbayaruuganbayar-ops?tab=repositories"]

    def parse(self, response):
        repo_links = response.css('a[itemprop="name codeRepository"]::attr(href)').getall()

        print("REPOS FOUND:", repo_links)  # debug

        for link in repo_links:
            yield response.follow(link, callback=self.parse_repo)

        next_page = response.css('a.next_page::attr(href)').get()
        if next_page:
            yield response.follow(next_page, callback=self.parse)

    def parse_repo(self, response):
        repo_name = response.css('strong a::text').get()

        about = response.css('p[itemprop="description"]::text').get()
        about = about.strip() if about else None

        # Check if repo is empty
        is_empty = response.css('h3:contains("Quick setup")').get() is not None

        if not about:
            if not is_empty:
                about = repo_name
            else:
                about = None

        last_updated = response.css('relative-time::attr(datetime)').get()

        if not is_empty:
            languages = response.css('span[itemprop="programmingLanguage"]::text').getall()
            languages = [l.strip() for l in languages if l.strip()]

            commits = response.css('span.d-none.d-sm-inline strong::text').get()
            commits = commits.strip() if commits else None
        else:
            languages = None
            commits = None

        yield {
            "url": response.url,
            "about": about,
            "last_updated": last_updated,
            "languages": languages,
            "commits": commits,
        }